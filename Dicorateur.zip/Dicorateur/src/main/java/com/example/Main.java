package com.example;

public class Main {
    static void afficher(Boisson b) {
        System.out.println(b.getDescription() + " = " + b.getPrix() + "DA");
    }
    public static void main(String[] args) {
        Boisson b1 = new Esprisso();
        afficher(b1);

        Boisson b2 = new Sucre(new Lait(new Lait(new Esprisso())));
        afficher(b2);

        Boisson b3 = new Esprisso();
        b3 = new Sucre(b3);
        b3 = new Lait(b3);
        b3 = new Sucre(b3);
        b3 = new Lait(b3);
        afficher(b3);
    }
}
