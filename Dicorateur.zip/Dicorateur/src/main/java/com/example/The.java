package com.example;

public class The implements Boisson{
    public String getDescription(){
        return "the";
    }
    public double getPrix(){
        return 100;
    }
}