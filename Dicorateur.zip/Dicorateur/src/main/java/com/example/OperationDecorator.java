package com.example;

public abstract class OperationDecorator implements Boisson {

    protected Boisson boisson;

    public OperationDecorator(Boisson boisson) {
        this.boisson = boisson;
    }

    public String getDescription() { return boisson.getDescription(); }
    public double getPrix()        { return boisson.getPrix(); }
}
