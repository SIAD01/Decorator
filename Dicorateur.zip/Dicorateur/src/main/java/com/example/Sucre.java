package com.example;

public class Sucre extends OperationDecorator {
    public Sucre(Boisson boisson){
        super(boisson);
    }

    public String getDescription(){
        return super.getDescription() + "+ Sucre";
    }
    public double getPrix(){
        return super.getPrix() + 10;    
    }
}