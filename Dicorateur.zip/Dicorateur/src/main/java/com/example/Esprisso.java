package com.example;

public class Esprisso implements Boisson{
    public String getDescription(){
        return "esprisso";
    }
    public double getPrix(){
        return 150;
    }
}