package com.example;

public interface Boisson{
    String getDescription();
    double getPrix();
}