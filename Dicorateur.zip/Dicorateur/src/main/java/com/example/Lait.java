package com.example;

public class Lait extends OperationDecorator {
    public Lait(Boisson boisson) {
        super(boisson);
    }

    public String getDescription() { return super.getDescription() + "+ lait";}
    public double getPrix()        { return super.getPrix() + 30; }
}